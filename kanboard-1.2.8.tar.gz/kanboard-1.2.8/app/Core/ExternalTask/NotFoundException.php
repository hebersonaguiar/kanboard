<?php

namespace Kanboard\Core\ExternalTask;

/**
 * Class NotFoundException
 *
 * @package Kanboard\Core\ExternalTask
 * @author  Frederic Guillot
 */
class NotFoundException extends ExternalTaskException
{
}
